import numpy as np
import matplotlib.pyplot as plt

def Needle_EMG_Decomposition():
    file1 = open('Data.txt', 'r')
    original = file1.readlines()

    with open("RectifiedData", "w") as file2:
        for line in original:
            rectified_value = str(abs(float(line))) + '\n'
            file2.write(rectified_value)
    file1.close()

    rectified_data = []
    with open('RectifiedData', 'r') as file:
        for line in file:
            value = float(line.strip())
            rectified_data.append(value)


    start_index = 0
    end_index = 78124

    signal = rectified_data[20:120]


    threshold = 12.05
    print(threshold)

    # Define the window size and threshold
    window_size = 20  # T
    M = []  # points in each MUAP #NRAGE3
    M2 = []
    above_average = []
    moving_average = []

    for i in range(start_index, end_index + 1):
        # Extract the current window of samples
        window = rectified_data[i:i + window_size]

        # Compute the average of the window
        average = sum(window) / window_size
        moving_average.append(average)

    above_threshold = False
    start_index = 0
    end_index = 0
    segment_length = 0
    above_average = []

    for i, value in enumerate(moving_average):
        if value > threshold:
            if not above_threshold:
                above_threshold = True
                start_index = i
        else:
            if above_threshold:
                above_threshold = False
                end_index = i - 1
                segment_length = end_index - start_index + 1
                if segment_length >= 20:

                    above_average.append((start_index, end_index))

                if end_index > len(moving_average):
                    end_index = len(moving_average) - 1

    print(above_average)
    print(len(above_average))

    original = [float(value) for value in original]
    MUAP = []
    for i in range(len(above_average)):
        M = [float(value) for value in original[above_average[i][0]:above_average[i][0] + 30]]
        peak = max(M)
        peak_index = original.index(peak)
        # print(peak_index)
        M2 = [float(value) for value in original[peak_index - 9:peak_index + 10]]
        if peak_index > len(original):
            break

        MUAP.append(M2)

    print(MUAP)
    print(len(MUAP))

    DiffTh = pow(12, 5)
    Templates = []
    Templates.append(MUAP[2])

    signal_templates = {}
    for i in range(len(MUAP)):
        D = [0] * len(Templates)  # Initialize D for each MUAP

        for j in range(len(MUAP[i])):
            for k in range(len(Templates)):
                temp = pow((MUAP[i][j] - Templates[k][j]), 2)
                D[k] += temp

        min_D = min(D)
        min_index = D.index(min_D)

        if min_D > DiffTh:
            Templates.append(MUAP[i])
        else:
            if isinstance(Templates[min_index], list):
                # Compute the average of existing samples in the template
                average_samples = [(Templates[min_index][j] + MUAP[i][j]) / 2 for j in range(len(Templates[min_index]))]
            else:
                # Create a new list template with the average of existing and new values
                average_samples = [(Templates[min_index] + MUAP[i][j]) / 2 for j in range(len(MUAP[i]))]
            Templates[min_index] = average_samples  # Update the template with the average values
            signal_templates[tuple(MUAP[i])] = min_index

    for signal, template_number in signal_templates.items():
        print(f"Signal: {signal},Template Number: {template_number}")

    print(" The Number of templates: ")
    print(len(Templates))

    # Plotting the original signal
    x = range(30000, 35001)
    y = original[30000:35001]
    plt.plot(x, y, label='Original Signal')

    peaktimestamps=[]
    # Plotting the peaks of each MUAP
    template_colors = ['red', 'green', 'green', 'green', 'blue']
    for i, muap in enumerate(MUAP):
        peak = max(muap)
        peak_index = original.index(peak)
        peaktimestamps.append(peak_index)
        if peak_index >= 30000 and peak_index <= 35000:
            star_color = template_colors[signal_templates.get(tuple(muap), -1)] # -1 means if it did not find the appropriate template, it defaults it to -1
            plt.scatter(peak_index, 900, marker='*', color=star_color)

    print ( " these are the timestamps for each peak: ")
    print (peaktimestamps)

    plt.title('Original Signal with MUAP Peaks with range from 30000, 35000')
    plt.xlabel('Sample Index')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.show()

    plt.plot(range(len(Templates[0])), Templates[0])
    plt.title('TEMPLATE1')
    plt.show()

    plt.plot(range(len(Templates[1])), Templates[1])
    plt.title('TEMPLATE2')
    plt.show()

    plt.plot(range(len(Templates[4])), Templates[4])
    plt.title('TEMPLATE3')
    plt.show()

    peakfreq = []

    for template, template_number in signal_templates.items():
        peak = max(template)
        peak_index = original.index(peak)
        peakfreq.append((template_number, peak_index))

        print(peakfreq)

    bit1 = [0] * end_index
    bit2 = [0] * end_index
    bit3 = [0] * end_index
    for j in range(len(peakfreq)):
        if peakfreq[j][0] == 0:
            bit1[peakfreq[j][1]] = 1
        elif peakfreq[j][0] == 1:
            bit2[peakfreq[j][1]] = 1
        elif peakfreq[j][0] == 4:
            bit3[peakfreq[j][1]] = 1

    print("vector 1:")
    print(bit1)
    print("vector 2:")
    print(bit2)
    print("vector 3:")
    print(bit3)

    spectrum1 = np.fft.fft(bit1)
    spectrum2 = np.fft.fft(bit2)
    spectrum3 = np.fft.fft(bit3)


    sampling_rate = 1  # Assuming a sampling rate of 1 unit per time step
    frequencies = np.fft.fftfreq(len(bit1), d=1 / sampling_rate)

    # Plot the spectrum
    plt.stem(frequencies, np.abs(spectrum1))
    plt.xlabel('Frequency')
    plt.ylabel('Magnitude')
    plt.title('Spectrum of Binary Vector 1')
    plt.show()

    plt.stem(frequencies, np.abs(spectrum2))
    plt.xlabel('Frequency')
    plt.ylabel('Magnitude')
    plt.title('Spectrum of Binary Vector 2')
    plt.show()

    plt.stem(frequencies, np.abs(spectrum3))
    plt.xlabel('Frequency')
    plt.ylabel('Magnitude')
    plt.title('Spectrum of Binary Vector 3')
    plt.show()




    return Templates, peaktimestamps


Needle_EMG_Decomposition()


